<?php $__env->startSection('content'); ?>
<div>
    <div class="page-header">
        <div>
            <h1 class="page-title">Verifikasi Pembayaran</h1>
            <p class="page-subtitle">Periksa bukti transfer dari pelanggan.</p>
        </div>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>" class="text-decoration-none text-muted-green">Home</a></li>
                <li class="breadcrumb-item active text-main" aria-current="page">Pembayaran</li>
            </ol>
        </nav>
    </div>

    <div class="table-card-custom">
        <div class="table-header-control">
            <h5 class="mb-0">Data Pembayaran</h5>
        </div>
        <div class="table-responsive">
            <table class="table-custom">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Kode Order</th>
                        <th>Pelanggan</th>
                        <th>Jumlah Transfer</th>
                        <th>Tanggal Upload</th>
                        <th>Status</th>
                        <th class="text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    
                    <?php $__empty_1 = true; $__currentLoopData = $pembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td class="table-order-id"><?php echo e($item->order->kode_order); ?></td>
                        <td><?php echo e($item->order->customer->nama); ?></td>
                        <td class="table-amount">Rp <?php echo e(number_format($item->jumlah_transfer, 0, ',', '.')); ?></td>
                        <td><?php echo e($item->created_at->format('d-m-Y H:i')); ?></td>
                        <td>
                            <span class="badge-table <?php echo e($item->status_verifikasi == 'diterima' ? 'success' : ($item->status_verifikasi == 'ditolak' ? 'failed' : 'pending')); ?>">
                                <?php echo e(ucfirst($item->status_verifikasi)); ?>

                            </span>
                        </td>
                        <td>
                            <div class="d-flex justify-content-center gap-1">
                                <?php if($item->status_verifikasi == 'menunggu'): ?>
                                <a href="<?php echo e(route('admin.pembayaran.validasi', $item->id_payment)); ?>" class="table-btn-action" title="Validasi pembayaran">
                                    <i class="bi bi-check-circle"></i>
                                </a>
                                <?php else: ?>
                                <a href="<?php echo e(route('admin.pembayaran.show', $item->id_payment)); ?>" class="table-btn-action" title="Lihat detail">
                                    <i class="bi bi-eye"></i>
                                </a>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="text-center py-4">Belum ada pembayaran</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="table-footer-control">
            <span class="table-pagination-info">Total <?php echo e($pembayaran->count()); ?> pembayaran</span>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\www\layanan-catering\resources\views/admin/pages/pembayaran/pembayaran.blade.php ENDPATH**/ ?>