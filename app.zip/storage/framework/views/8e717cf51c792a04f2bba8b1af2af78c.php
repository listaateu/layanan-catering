<?php $__env->startSection('content'); ?>
<!-- Judul Halaman -->
<div class="breadcam_area breadcam_bg_1 zigzag_bg_2">
    <div class="breadcam_inner">
        <div class="breadcam_text">
            <h3>Pesanan Saya</h3>
            <p>Semua pesanan yang pernah kamu buat.</p>
        </div>
    </div>
</div>
<!-- Judul Halaman -->

<section class="contact-section">
    <div class="container">
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Kode Order</th>
                        <th>Menu</th>
                        <th>Tanggal Acara</th>
                        <th>Total Bayar</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $pesanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($item->kode_order); ?></td>
                        <td>
                            <?php $__currentLoopData = $item->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div><?php echo e($detail->package->nama_paket); ?> (<?php echo e($detail->jumlah_porsi); ?> porsi)</div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        <td><?php echo e($item->tanggal_acara->format('d-m-Y')); ?></td>
                        <td>Rp <?php echo e(number_format($item->total_bayar, 0, ',', '.')); ?></td>
                        <td><span class="badge status-<?php echo e($item->status_badge); ?>"><?php echo e($item->status_label); ?></span></td>
                        <td><a href="<?php echo e(route('pelanggan.pesanan.show', $item->id_order)); ?>" class="btn btn-sm btn-outline-secondary">Detail</a></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="text-center">Kamu belum punya pesanan. <a href="<?php echo e(route('pelanggan.menu')); ?>">Lihat menu</a></td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pelanggan.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\www\layanan-catering\resources\views/pelanggan/pages/pesanan/pesanan.blade.php ENDPATH**/ ?>