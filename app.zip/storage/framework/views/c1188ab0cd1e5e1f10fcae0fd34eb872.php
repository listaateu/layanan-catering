<?php if(session('success')): ?>
<div class="alert alert-success fade show m-3" role="alert">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>
<?php if(session('error')): ?>
<div class="alert alert-danger fade show m-3" role="alert">
    <?php echo e(session('error')); ?>

</div>
<?php endif; ?>
<?php /**PATH D:\www\layanan-catering\resources\views/admin/components/alert.blade.php ENDPATH**/ ?>