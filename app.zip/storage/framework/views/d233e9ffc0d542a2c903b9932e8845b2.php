<?php $__env->startSection('content'); ?>
<!-- Judul Halaman -->
<div class="breadcam_area breadcam_bg_1 zigzag_bg_2">
    <div class="breadcam_inner">
        <div class="breadcam_text">
            <h3>Menu Kami</h3>
            <p>Pilih paket yang kamu mau, lalu klik Pesan Sekarang.</p>
        </div>
    </div>
</div>
<!-- Judul Halaman -->

<!-- Daftar Paket -->
<div class="order_area">
    <div class="container">
        <div class="row">
            
            <?php $__empty_1 = true; $__currentLoopData = $paket; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php echo $__env->make('pelanggan.components.kartu-paket', ['item' => $item], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-12 text-center">Belum ada paket menu</div>
            <?php endif; ?>
        </div>
    </div>
</div>
<!-- Daftar Paket -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pelanggan.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\www\layanan-catering\resources\views/pelanggan/pages/menu.blade.php ENDPATH**/ ?>