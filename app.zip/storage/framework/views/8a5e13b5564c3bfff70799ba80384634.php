<?php $__env->startSection('content'); ?>
<div>
    <!-- Page Header -->
    <div class="page-header">
        <div>
            <h1 class="page-title">Paket Menu</h1>
            <p class="page-subtitle">Kelola daftar paket catering yang tersedia untuk pelanggan.</p>
        </div>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>" class="text-decoration-none text-muted-green">Home</a></li>
                <li class="breadcrumb-item active text-main" aria-current="page">Paket Menu</li>
            </ol>
        </nav>
    </div>
    <!-- Page Header -->

    <!-- Table Card -->
    <div class="table-card-custom">
        <div class="table-header-control">
            <h5 class="mb-0">Data Paket Menu</h5>
            <a href="<?php echo e(route('admin.paket.create')); ?>" class="btn-custom btn-custom-primary">
                <i class="bi bi-plus-lg"></i> Tambah Paket Menu
            </a>
        </div>

        <div class="table-responsive">
            <table class="table-custom">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Paket</th>
                        <th>Harga / Porsi</th>
                        <th>Min. Porsi</th>
                        <th>Status</th>
                        <th class="text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    
                    <?php $__empty_1 = true; $__currentLoopData = $paket; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="table-order-id"><?php echo e($loop->iteration); ?></td>
                        <td>
                            <div class="table-user-cell">
                                
                                <img src="<?php echo e($item->gambar_paket ? asset('storage/' . $item->gambar_paket) : asset('admin/spark/assets/images/avatar.png')); ?>"
                                    alt="<?php echo e($item->nama_paket); ?>" class="table-user-avatar" style="object-fit: cover;">
                                <div>
                                    <div class="table-user-name"><?php echo e($item->nama_paket); ?></div>
                                    <div class="table-user-sub"><?php echo e(Str::limit($item->deskripsi, 50)); ?></div>
                                </div>
                            </div>
                        </td>
                        <td class="table-amount">Rp <?php echo e(number_format($item->harga_porsi, 0, ',', '.')); ?></td>
                        <td><?php echo e($item->min_porsi); ?> porsi</td>
                        <td>
                            <span class="badge-table <?php echo e($item->status_aktif == 'aktif' ? 'success' : 'failed'); ?>">
                                <?php echo e($item->status_aktif == 'aktif' ? 'Aktif' : 'Non-Aktif'); ?>

                            </span>
                        </td>
                        <td>
                            <div class="d-flex justify-content-center gap-1">
                                <a href="<?php echo e(route('admin.paket.edit', $item->id_paket)); ?>" class="table-btn-action" title="Ubah data">
                                    <i class="bi bi-pencil"></i>
                                </a>
                                
                                <form action="<?php echo e(route('admin.paket.destroy', $item->id_paket)); ?>" method="post" onsubmit="return confirm('Data paket akan dihapus. Apakah anda yakin?')">
                                    <?php echo csrf_field(); ?>
                                    
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="table-btn-action delete" title="Hapus data">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="text-center py-4">Belum ada data paket menu</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="table-footer-control">
            <span class="table-pagination-info">Total <?php echo e($paket->count()); ?> paket menu</span>
        </div>
    </div>
    <!-- Table Card -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\www\layanan-catering\resources\views/admin/pages/paket/paket.blade.php ENDPATH**/ ?>