

<div class="col-xl-4 col-md-6">
    <div class="single_order">
        <div class="order_thumb">
            
            <img src="<?php echo e($item->gambar_paket ? asset('storage/' . $item->gambar_paket) : asset('flatter-master/img/order/order-1.png')); ?>"
                alt="<?php echo e($item->nama_paket); ?>" style="width: 100%; height: 260px; object-fit: cover;">
            <div class="order_prise">
                <span>Rp <?php echo e(number_format($item->harga_porsi, 0, ',', '.')); ?></span>
            </div>
        </div>
        <div class="order_info">
            
            <h3><a href="<?php echo e(route('pelanggan.menu.show', $item->id_paket)); ?>"><?php echo e($item->nama_paket); ?></a></h3>
            <p><?php echo e(Str::limit($item->deskripsi, 80)); ?> <br>
                Minimal <?php echo e($item->min_porsi); ?> porsi
            </p>
            
            <a href="<?php echo e(route('pelanggan.pesanan.create', $item->id_paket)); ?>" class="boxed_btn">Pesan Sekarang!</a>
            <a href="<?php echo e(route('pelanggan.menu.show', $item->id_paket)); ?>" class="d-inline-block ml-3">Lihat detail</a>
        </div>
    </div>
</div>
<?php /**PATH D:\www\layanan-catering\resources\views/pelanggan/components/kartu-paket.blade.php ENDPATH**/ ?>