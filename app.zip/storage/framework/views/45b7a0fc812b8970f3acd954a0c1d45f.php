<!doctype html>
<html lang="id">
<!-- Head Section -->
<?php echo $__env->make('admin.partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Head Section -->

<body>
    <!-- Sidebar -->
    <?php echo $__env->make('admin.components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Sidebar -->
    <!-- Main Content -->
    <div class="main-wrapper">
        <!-- Navbar -->
        <?php echo $__env->make('admin.components.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Navbar -->
        <!-- Alert -->
        <?php echo $__env->make('admin.components.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Alert -->
        <!-- Main Content -->
        <?php echo $__env->yieldContent('content'); ?>
        <!-- Main Content -->
        <!-- Footer Section -->
        <?php echo $__env->make('admin.components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Footer Section -->
    </div>
    <!-- Main Content -->

    <!-- Logout Modal -->
    <?php echo $__env->make('admin.components.logout-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Logout Modal -->

    <!-- Script Section -->
    <?php echo $__env->make('admin.partials.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Script Section -->
</body>

</html>
<?php /**PATH D:\www\layanan-catering\resources\views/admin/index.blade.php ENDPATH**/ ?>