<?php $__env->startSection('content'); ?>
<div>
    <div class="page-header">
        <div>
            <h1 class="page-title">Detail Riwayat</h1>
            <p class="page-subtitle"><?php echo e($produksi->order->kode_order); ?></p>
        </div>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="<?php echo e(route('dapur.dashboard')); ?>" class="text-decoration-none text-muted-green">Home</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('dapur.riwayat.table')); ?>" class="text-decoration-none text-muted-green">Riwayat</a></li>
                <li class="breadcrumb-item active text-main" aria-current="page">Detail</li>
            </ol>
        </nav>
    </div>

    <div class="row mb-4">
        <div class="col-12 col-lg-8">
            <div class="card border-light shadow-sm p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h5 class="card-title mb-0">Informasi Pesanan</h5>
                    <span class="badge-table <?php echo e($produksi->status_badge); ?>"><?php echo e($produksi->status_label); ?></span>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label-custom">Tanggal Acara</label>
                        <input type="text" class="form-control-custom" value="<?php echo e($produksi->order->tanggal_acara->format('d-m-Y')); ?>" readonly>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label-custom">Jam Kirim</label>
                        <input type="text" class="form-control-custom" value="<?php echo e(substr($produksi->order->jam_kirim, 0, 5)); ?>" readonly>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label-custom">Alamat Kirim</label>
                    <textarea class="form-control-custom" rows="3" readonly><?php echo e($produksi->order->alamat_kirim); ?></textarea>
                </div>
                <div class="mb-3">
                    <label class="form-label-custom">Penanggung Jawab</label>
                    <input type="text" class="form-control-custom" value="<?php echo e($produksi->handler->nama ?? '-'); ?>" readonly>
                </div>

                <h6 class="mt-2 mb-2">Menu</h6>
                <div class="table-responsive mb-3">
                    <table class="table-custom">
                        <thead>
                            <tr>
                                <th>Paket</th>
                                <th>Jumlah Porsi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $produksi->order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($detail->package->nama_paket); ?></td>
                                <td><?php echo e($detail->jumlah_porsi); ?> porsi</td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                <div>
                    <a href="<?php echo e(route('dapur.riwayat.table')); ?>" class="btn-custom btn-custom-light">Kembali</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dapur.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\www\layanan-catering\resources\views/dapur/pages/riwayat/show.blade.php ENDPATH**/ ?>