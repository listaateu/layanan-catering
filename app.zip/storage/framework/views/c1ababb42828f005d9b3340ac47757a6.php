<?php $__env->startSection('content'); ?>
<div>
    <div class="page-header">
        <div>
            <h1 class="page-title">Riwayat</h1>
            <p class="page-subtitle">Pesanan yang sudah selesai dikirim.</p>
        </div>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="<?php echo e(route('dapur.dashboard')); ?>" class="text-decoration-none text-muted-green">Home</a></li>
                <li class="breadcrumb-item active text-main" aria-current="page">Riwayat</li>
            </ol>
        </nav>
    </div>

    <div class="table-card-custom">
        <div class="table-header-control">
            <h5 class="mb-0">Riwayat Produksi</h5>
        </div>

        <div class="table-responsive">
            <table class="table-custom">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Kode Order</th>
                        <th>Menu</th>
                        <th>Tanggal Acara</th>
                        <th>Status</th>
                        <th>Penanggung Jawab</th>
                        <th class="text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $riwayat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td class="table-order-id"><?php echo e($item->order->kode_order); ?></td>
                        <td>
                            <?php $__currentLoopData = $item->order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div><?php echo e($detail->package->nama_paket); ?> <span class="table-user-sub">(<?php echo e($detail->jumlah_porsi); ?> porsi)</span></div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        <td><?php echo e($item->order->tanggal_acara->format('d-m-Y')); ?></td>
                        <td><span class="badge-table <?php echo e($item->status_badge); ?>"><?php echo e($item->status_label); ?></span></td>
                        <td><?php echo e($item->handler->nama ?? '-'); ?></td>
                        <td>
                            <div class="d-flex justify-content-center gap-1">
                                <a href="<?php echo e(route('dapur.riwayat.show', $item->id_produksi)); ?>" class="table-btn-action" title="Lihat detail">
                                    <i class="bi bi-eye"></i>
                                </a>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="text-center py-4">Belum ada riwayat pesanan</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="table-footer-control">
            <span class="table-pagination-info">Total <?php echo e($riwayat->count()); ?> riwayat</span>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dapur.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\www\layanan-catering\resources\views/dapur/pages/riwayat/riwayat.blade.php ENDPATH**/ ?>