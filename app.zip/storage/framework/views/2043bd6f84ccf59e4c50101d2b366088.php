



<!doctype html>
<html class="no-js" lang="id">
<!-- Head Section -->
<?php echo $__env->make('pelanggan.partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Head Section -->

<body>
    <!-- Navbar -->
    <?php echo $__env->make('pelanggan.components.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Navbar -->

    <!-- Alert -->
    <?php echo $__env->make('pelanggan.components.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Alert -->

    <!-- Main Content -->
    <?php echo $__env->yieldContent('content'); ?>
    <!-- Main Content -->

    <!-- Footer Section -->
    <?php echo $__env->make('pelanggan.components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Footer Section -->

    <!-- Script Section -->
    <?php echo $__env->make('pelanggan.partials.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Script Section -->
</body>

</html>
<?php /**PATH D:\www\layanan-catering\resources\views/pelanggan/index.blade.php ENDPATH**/ ?>