<?php $__env->startSection('content'); ?>
<!-- Judul Halaman -->
<div class="breadcam_area breadcam_bg_1 zigzag_bg_2">
    <div class="breadcam_inner">
        <div class="breadcam_text">
            <h3>Detail Paket</h3>
            <p><?php echo e($paket->nama_paket); ?></p>
        </div>
    </div>
</div>
<!-- Judul Halaman -->

<section class="contact-section">
    <div class="container">
        <div class="row">
            <!-- Gambar -->
            <div class="col-lg-6 mb-4">
                <img src="<?php echo e($paket->gambar_paket ? asset('storage/' . $paket->gambar_paket) : asset('flatter-master/img/order/order-1.png')); ?>"
                    alt="<?php echo e($paket->nama_paket); ?>" style="width: 100%; max-height: 420px; object-fit: cover;">
            </div>

            <!-- Keterangan -->
            <div class="col-lg-6">
                <h2><?php echo e($paket->nama_paket); ?></h2>
                <h4 class="my-3">Rp <?php echo e(number_format($paket->harga_porsi, 0, ',', '.')); ?> <small class="text-muted">/ porsi</small></h4>
                <p>Minimal pesan: <strong><?php echo e($paket->min_porsi); ?> porsi</strong></p>

                <h5 class="mt-4">Isi Paket</h5>
                
                <ul class="isi-paket">
                    <?php $__currentLoopData = explode(',', $paket->deskripsi); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $isi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e(trim($isi)); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>

                <div class="mt-4">
                    <a href="<?php echo e(route('pelanggan.pesanan.create', $paket->id_paket)); ?>" class="boxed_btn">Pesan Sekarang!</a>
                    <a href="<?php echo e(route('pelanggan.menu')); ?>" class="d-inline-block ml-3">Kembali ke menu</a>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pelanggan.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\www\layanan-catering\resources\views/pelanggan/pages/detail.blade.php ENDPATH**/ ?>