<footer class="footer-custom">
    <div class="footer-left">
        <span class="footer-logo">
            <i class="bi bi-egg-fried"></i> Dapur Catering
        </span>
        <span class="footer-separator">|</span>
        <span class="footer-copy">&copy; <?php echo e(date('Y')); ?> Template Spark Admin by ThemeWagon</span>
    </div>
</footer>
<?php /**PATH D:\www\layanan-catering\resources\views/dapur/components/footer.blade.php ENDPATH**/ ?>