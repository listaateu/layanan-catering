<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Layanan Catering</title>
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('admin/spark/assets/images/favicon.ico')); ?>">

    <!-- Bootstrap -->
    <link rel="stylesheet" href="<?php echo e(asset('admin/spark/assets/libs/bootstrap/css/bootstrap.min.css')); ?>" />

    <!-- Bootstrap Icon -->
    <link rel="stylesheet" href="<?php echo e(asset('admin/spark/assets/libs/bootstrap-icons/bootstrap-icons.css')); ?>" />

    <!-- Apexcharts & Flatpickr -->
    <link rel="stylesheet" href="<?php echo e(asset('admin/spark/assets/libs/apexcharts/apexcharts.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('admin/spark/assets/libs/flatpickr/flatpickr.min.css')); ?>" />

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Mulish:wght@400;600;700&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet">

    <!-- Sweetalert2 -->
    <link
        rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/sweetalert2@11.26.25/dist/sweetalert2.min.css" />

    <!-- Local Style -->
    <link rel="stylesheet" href="<?php echo e(asset('admin/spark/assets/css/main.css')); ?>" />
</head>
<?php /**PATH D:\www\layanan-catering\resources\views/admin/partials/head.blade.php ENDPATH**/ ?>