<!-- header-start -->
<header>
    <div class="header-area ">
        <div id="sticky-header" class="main-header-area">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-xl-10 col-lg-10">
                        <div class="main-menu d-none d-lg-block">
                            <nav>
                                <ul class="mein_menu_list" id="navigation">
                                    <li><a href="<?php echo e(route('pelanggan.beranda')); ?>" class="<?php echo e(request()->routeIs('pelanggan.beranda') ? 'active' : ''); ?>">Beranda</a></li>
                                    <li><a href="<?php echo e(route('pelanggan.menu')); ?>" class="<?php echo e(request()->routeIs('pelanggan.menu*') ? 'active' : ''); ?>">Menu</a></li>
                                    <li><a href="<?php echo e(route('pelanggan.tentang')); ?>" class="<?php echo e(request()->routeIs('pelanggan.tentang') ? 'active' : ''); ?>">Tentang</a></li>
                                    <div class="logo-img d-none d-lg-block">
                                        <a href="<?php echo e(route('pelanggan.beranda')); ?>">
                                            <img src="<?php echo e(asset('flatter-master/img/logo.png')); ?>" alt="">
                                        </a>
                                    </div>
                                    <li><a href="<?php echo e(route('pelanggan.kontak')); ?>" class="<?php echo e(request()->routeIs('pelanggan.kontak') ? 'active' : ''); ?>">Kontak</a></li>
                                    
                                    <?php if(auth()->check()): ?>
                                    <li><a href="<?php echo e(route('pelanggan.pesanan.table')); ?>" class="<?php echo e(request()->routeIs('pelanggan.pesanan*') ? 'active' : ''); ?>">Pesanan Saya</a></li>
                                    <?php endif; ?>
                                    
                                    <li class="d-lg-none">
                                        <?php if(auth()->check()): ?>
                                        <form action="<?php echo e(route('logout')); ?>" method="post" class="m-0" onsubmit="return confirm('Yakin ingin logout?')">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="logout-btn border-0 p-0 text-white">Logout</button>
                                        </form>
                                        <?php else: ?>
                                        <a href="<?php echo e(route('login')); ?>">Login</a>
                                        <?php endif; ?>
                                    </li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                    <div class="col-xl-2 col-lg-2 d-none d-lg-block">
                        <div class="custom_order">
                            
                            <?php if(auth()->check()): ?>
                            
                            <form action="<?php echo e(route('logout')); ?>" method="post" class="m-0" onsubmit="return confirm('Yakin ingin logout?')">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="boxed_btn_white logout-btn">Logout</button>
                            </form>
                            <?php else: ?>
                            <a href="<?php echo e(route('login')); ?>" class="boxed_btn_white">Login</a>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="mobile_menu d-block d-lg-none"></div>
                    </div>
                    <div class="logo-img-small d-sm-block d-md-block d-lg-none">
                        <a href="<?php echo e(route('pelanggan.beranda')); ?>">
                            <img src="<?php echo e(asset('flatter-master/img/logo.png')); ?>" alt="">
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>
<!-- header-end -->
<?php /**PATH D:\www\layanan-catering\resources\views/pelanggan/components/navbar.blade.php ENDPATH**/ ?>