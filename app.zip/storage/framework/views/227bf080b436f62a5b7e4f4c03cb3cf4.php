<?php $__env->startSection('content'); ?>
<!-- Judul Halaman -->
<div class="breadcam_area breadcam_bg_1 zigzag_bg_2">
    <div class="breadcam_inner">
        <div class="breadcam_text">
            <h3>Detail Pesanan</h3>
            <p><?php echo e($pesanan->kode_order); ?></p>
        </div>
    </div>
</div>
<!-- Judul Halaman -->

<section class="contact-section">
    <div class="container">
        <div class="row">
            <!-- Info Pesanan -->
            <div class="col-lg-7 mb-4">
                <h4>Informasi Pesanan <span class="badge status-<?php echo e($pesanan->status_badge); ?>"><?php echo e($pesanan->status_label); ?></span></h4>
                <table class="table mt-3">
                    <tr><th style="width: 35%;">Tanggal Acara</th><td><?php echo e($pesanan->tanggal_acara->format('d-m-Y')); ?></td></tr>
                    <tr><th>Jam Kirim</th><td><?php echo e(substr($pesanan->jam_kirim, 0, 5)); ?></td></tr>
                    <tr><th>Alamat Kirim</th><td><?php echo e($pesanan->alamat_kirim); ?></td></tr>
                    <tr><th>Total Bayar</th><td>Rp <?php echo e(number_format($pesanan->total_bayar, 0, ',', '.')); ?></td></tr>
                </table>

                <h5 class="mt-4">Isi Pesanan</h5>
                <table class="table">
                    <thead>
                        <tr><th>Paket</th><th>Porsi</th><th>Harga</th><th>Subtotal</th></tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $pesanan->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($detail->package->nama_paket); ?></td>
                            <td><?php echo e($detail->jumlah_porsi); ?></td>
                            <td>Rp <?php echo e(number_format($detail->harga_satuan, 0, ',', '.')); ?></td>
                            <td>Rp <?php echo e(number_format($detail->subtotal, 0, ',', '.')); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

                
                <?php if(in_array($pesanan->status_pesanan, ['menunggu_pembayaran', 'menunggu_verifikasi', 'terkonfirmasi'])): ?>
                
                <form action="<?php echo e(route('pelanggan.pesanan.batal', $pesanan->id_order)); ?>" method="post" onsubmit="return confirm('Yakin ingin membatalkan pesanan ini? Pengembalian dana diurus langsung dengan admin.')">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <button type="submit" class="btn btn-danger">Batalkan Pesanan</button>
                </form>
                <?php endif; ?>
            </div>

            <!-- Pembayaran -->
            <div class="col-lg-5">
                <h4>Pembayaran</h4>

                <?php if($pesanan->payment): ?>
                <p class="mt-3 mb-1">
                    Status bukti transfer:
                    <span class="badge <?php echo e($pesanan->payment->status_verifikasi == 'diterima' ? 'status-success' : ($pesanan->payment->status_verifikasi == 'ditolak' ? 'status-failed' : 'status-pending')); ?>"><?php echo e(ucfirst($pesanan->payment->status_verifikasi)); ?></span>
                </p>
                <p class="mb-3">Jumlah transfer: Rp <?php echo e(number_format($pesanan->payment->jumlah_transfer, 0, ',', '.')); ?></p>
                <?php if($pesanan->payment->status_verifikasi == 'ditolak' && $pesanan->status_pesanan == 'menunggu_pembayaran'): ?>
                <div class="alert alert-warning">Bukti transfer sebelumnya ditolak admin. Silakan upload ulang bukti yang benar.</div>
                <?php endif; ?>
                <?php endif; ?>

                
                <?php if($pesanan->status_pesanan == 'menunggu_pembayaran'): ?>
                
                <form action="<?php echo e(route('pelanggan.pembayaran.store', $pesanan->id_order)); ?>" method="post" enctype="multipart/form-data" class="mt-3">
                    <?php echo csrf_field(); ?>

                    <div class="form-group">
                        <label for="jumlah_transfer">Jumlah Transfer <span class="text-danger">*</span></label>
                        <input type="number" class="form-control" name="jumlah_transfer" id="jumlah_transfer" value="<?php echo e(old('jumlah_transfer', (int) $pesanan->total_bayar)); ?>" min="1" required>
                    </div>

                    <div class="form-group">
                        <label for="bukti_transfer">Bukti Transfer <span class="text-danger">*</span></label>
                        <input type="file" class="form-control-file" name="bukti_transfer" id="bukti_transfer" accept="image/*" required>
                        <small class="text-muted">Format JPG atau PNG, maksimal 2 MB.</small>
                    </div>

                    <button type="submit" class="boxed_btn">Kirim Bukti</button>
                </form>
                <?php elseif($pesanan->status_pesanan == 'menunggu_verifikasi'): ?>
                <p class="mt-3">Bukti transfermu sedang dicek admin.</p>
                <?php endif; ?>

                
                <?php if($pesanan->productionSchedule): ?>
                <h4 class="mt-4">Proses Dapur</h4>
                <p class="mt-2">Status: <span class="badge status-<?php echo e($pesanan->productionSchedule->status_badge); ?>"><?php echo e($pesanan->productionSchedule->status_label); ?></span></p>
                <?php endif; ?>
            </div>
        </div>

        <div class="mt-4">
            <a href="<?php echo e(route('pelanggan.pesanan.table')); ?>" class="boxed_btn_white">Kembali</a>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pelanggan.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\www\layanan-catering\resources\views/pelanggan/pages/pesanan/show.blade.php ENDPATH**/ ?>