<?php $__env->startSection('content'); ?>
<div>
    <div class="page-header">
        <div>
            <h1 class="page-title">Pesanan</h1>
            <p class="page-subtitle">Pantau semua pesanan catering dari pelanggan.</p>
        </div>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>" class="text-decoration-none text-muted-green">Home</a></li>
                <li class="breadcrumb-item active text-main" aria-current="page">Pesanan</li>
            </ol>
        </nav>
    </div>

    <div class="table-card-custom">
        <div class="table-header-control">
            <h5 class="mb-0">Data Pesanan</h5>
            <div class="table-filter-group">
                <div class="dropdown">
                    <button class="btn-table-action dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="bi bi-funnel"></i> <span class="text-capitalize"><?php echo e($status ? str_replace('_', ' ', $status) : 'Semua Status'); ?></span>
                    </button>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="<?php echo e(route('admin.pesanan.table')); ?>">Semua Status</a></li>
                        
                        <li><a class="dropdown-item" href="<?php echo e(route('admin.pesanan.table', ['status' => 'menunggu_pembayaran'])); ?>">Menunggu Pembayaran</a></li>
                        <li><a class="dropdown-item" href="<?php echo e(route('admin.pesanan.table', ['status' => 'menunggu_verifikasi'])); ?>">Menunggu Verifikasi</a></li>
                        <li><a class="dropdown-item" href="<?php echo e(route('admin.pesanan.table', ['status' => 'terkonfirmasi'])); ?>">Terkonfirmasi</a></li>
                        <li><a class="dropdown-item" href="<?php echo e(route('admin.pesanan.table', ['status' => 'diproses'])); ?>">Diproses</a></li>
                        <li><a class="dropdown-item" href="<?php echo e(route('admin.pesanan.table', ['status' => 'selesai'])); ?>">Selesai</a></li>
                        <li><a class="dropdown-item" href="<?php echo e(route('admin.pesanan.table', ['status' => 'dibatalkan'])); ?>">Dibatalkan</a></li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="table-responsive">
            <table class="table-custom">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Kode Order</th>
                        <th>Pelanggan</th>
                        <th>Tanggal Acara</th>
                        <th>Total Bayar</th>
                        <th>Status</th>
                        <th class="text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    
                    <?php $__empty_1 = true; $__currentLoopData = $pesanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td class="table-order-id"><?php echo e($item->kode_order); ?></td>
                        <td>
                            <div class="table-user-name"><?php echo e($item->customer->nama); ?></div>
                            <div class="table-user-sub"><?php echo e($item->customer->nomor_telepon); ?></div>
                        </td>
                        <td>
                            <?php echo e($item->tanggal_acara->format('d-m-Y')); ?>

                            <div class="table-user-sub">Pukul <?php echo e(substr($item->jam_kirim, 0, 5)); ?></div>
                        </td>
                        <td class="table-amount">Rp <?php echo e(number_format($item->total_bayar, 0, ',', '.')); ?></td>
                        <td><span class="badge-table <?php echo e($item->status_badge); ?>"><?php echo e($item->status_label); ?></span></td>
                        <td>
                            <div class="d-flex justify-content-center gap-1">
                                <a href="<?php echo e(route('admin.pesanan.show', $item->id_order)); ?>" class="table-btn-action" title="Lihat detail">
                                    <i class="bi bi-eye"></i>
                                </a>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="text-center py-4">Belum ada pesanan</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="table-footer-control">
            <span class="table-pagination-info">Total <?php echo e($pesanan->count()); ?> pesanan</span>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\www\layanan-catering\resources\views/admin/pages/pesanan/pesanan.blade.php ENDPATH**/ ?>