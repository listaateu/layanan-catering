
<script src="<?php echo e(asset('flatter-master/js/vendor/modernizr-3.5.0.min.js')); ?>"></script>
<script src="<?php echo e(asset('flatter-master/js/vendor/jquery-1.12.4.min.js')); ?>"></script>
<script src="<?php echo e(asset('flatter-master/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('flatter-master/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('flatter-master/js/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('flatter-master/js/isotope.pkgd.min.js')); ?>"></script>
<script src="<?php echo e(asset('flatter-master/js/waypoints.min.js')); ?>"></script>
<script src="<?php echo e(asset('flatter-master/js/jquery.counterup.min.js')); ?>"></script>
<script src="<?php echo e(asset('flatter-master/js/imagesloaded.pkgd.min.js')); ?>"></script>
<script src="<?php echo e(asset('flatter-master/js/scrollIt.js')); ?>"></script>
<script src="<?php echo e(asset('flatter-master/js/jquery.scrollUp.min.js')); ?>"></script>
<script src="<?php echo e(asset('flatter-master/js/wow.min.js')); ?>"></script>
<script src="<?php echo e(asset('flatter-master/js/nice-select.min.js')); ?>"></script>
<script src="<?php echo e(asset('flatter-master/js/jquery.slicknav.min.js')); ?>"></script>
<script src="<?php echo e(asset('flatter-master/js/jquery.magnific-popup.min.js')); ?>"></script>
<script src="<?php echo e(asset('flatter-master/js/plugins.js')); ?>"></script>

<script src="<?php echo e(asset('flatter-master/js/jquery.ajaxchimp.min.js')); ?>"></script>
<script src="<?php echo e(asset('flatter-master/js/main.js')); ?>"></script>
<?php /**PATH D:\www\layanan-catering\resources\views/pelanggan/partials/script.blade.php ENDPATH**/ ?>