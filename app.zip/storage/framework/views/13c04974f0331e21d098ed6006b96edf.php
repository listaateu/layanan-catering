<?php $__env->startSection('content'); ?>
<div>
    <div class="page-header">
        <div>
            <h1 class="page-title">Ubah Status Produksi</h1>
            <p class="page-subtitle"><?php echo e($produksi->order->kode_order); ?></p>
        </div>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="<?php echo e(route('dapur.dashboard')); ?>" class="text-decoration-none text-muted-green">Home</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('dapur.produksi.table')); ?>" class="text-decoration-none text-muted-green">Produksi</a></li>
                <li class="breadcrumb-item active text-main" aria-current="page">Ubah Status</li>
            </ol>
        </nav>
    </div>

    <div class="row g-4 mb-4">
        <!-- Detail Pesanan (hanya dibaca) -->
        <div class="col-12 col-lg-7">
            <div class="card border-light shadow-sm p-4 h-100">
                <h5 class="card-title mb-4">Detail Pesanan</h5>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label-custom">Tanggal Acara</label>
                        <input type="text" class="form-control-custom" value="<?php echo e($produksi->order->tanggal_acara->format('d-m-Y')); ?>" readonly>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label-custom">Jam Kirim</label>
                        <input type="text" class="form-control-custom" value="<?php echo e(substr($produksi->order->jam_kirim, 0, 5)); ?>" readonly>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label-custom">Alamat Kirim</label>
                    <textarea class="form-control-custom" rows="3" readonly><?php echo e($produksi->order->alamat_kirim); ?></textarea>
                </div>

                <h6 class="mt-2 mb-2">Menu yang Harus Dimasak</h6>
                <div class="table-responsive">
                    <table class="table-custom">
                        <thead>
                            <tr>
                                <th>Paket</th>
                                <th>Jumlah Porsi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $produksi->order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($detail->package->nama_paket); ?></td>
                                <td><?php echo e($detail->jumlah_porsi); ?> porsi</td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Form Ubah Status -->
        <div class="col-12 col-lg-5">
            <div class="card border-light shadow-sm p-4 h-100">
                <h5 class="card-title mb-4">Ubah Status</h5>

                <div class="mb-3">
                    <label class="form-label-custom">Status Sekarang</label>
                    <div><span class="badge-table <?php echo e($produksi->status_badge); ?>"><?php echo e($produksi->status_label); ?></span></div>
                </div>

                
                <?php if($statusBerikut): ?>
                
                <form action="<?php echo e(route('dapur.produksi.update', $produksi->id_produksi)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="mb-4">
                        <label for="status_produksi" class="form-label-custom">Status Berikutnya <span class="text-danger">*</span></label>
                        
                        <select class="form-select-custom" name="status_produksi" id="status_produksi" required>
                            <option value="<?php echo e($statusBerikut); ?>" class="text-capitalize"><?php echo e(ucwords(str_replace('_', ' ', $statusBerikut))); ?></option>
                        </select>
                    </div>

                    <div class="d-flex gap-2">
                        <button type="submit" class="btn-custom btn-custom-primary">
                            <i class="bi bi-check-lg"></i> Simpan Status
                        </button>
                        <a href="<?php echo e(route('dapur.produksi.table')); ?>" class="btn-custom btn-custom-light">Batal</a>
                    </div>
                </form>
                <?php else: ?>
                <a href="<?php echo e(route('dapur.produksi.table')); ?>" class="btn-custom btn-custom-light">Kembali</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dapur.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\www\layanan-catering\resources\views/dapur/pages/produksi/update.blade.php ENDPATH**/ ?>