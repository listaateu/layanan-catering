<?php $__env->startSection('content'); ?>
<!-- Banner -->
<div class="slider_area">
    <div class="single_slider slider_img_1">
        <div class="single_slider-iner">
            <div class="slider_contant">
                <h3>Catering Lezat <br> untuk Setiap Acara</h3>
                <p>Pilih paket menu favoritmu, <br> kami yang menyiapkan dan mengantar.</p>
                <a href="<?php echo e(route('pelanggan.menu')); ?>" class="boxed_btn">Lihat Menu</a>
            </div>
        </div>
    </div>
</div>
<!-- Banner -->

<!-- Paket Terbaru -->
<div class="order_area">
    <div class="container">
        <div class="row">
            <div class="col-xl-12">
                <div class="section_title mb-70">
                    <h3>Paket Menu Terbaru</h3>
                    <p>Beberapa pilihan paket yang bisa kamu pesan.</p>
                </div>
            </div>
        </div>
        <div class="row">
            
            <?php $__empty_1 = true; $__currentLoopData = $paket; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php echo $__env->make('pelanggan.components.kartu-paket', ['item' => $item], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-12 text-center">Belum ada paket menu</div>
            <?php endif; ?>
        </div>
        <div class="row mt-4">
            <div class="col-12 text-center">
                <a href="<?php echo e(route('pelanggan.menu')); ?>" class="boxed_btn">Lihat Semua Menu</a>
            </div>
        </div>
    </div>
</div>
<!-- Paket Terbaru -->

<!-- Cara Pesan -->
<div class="single_about_area">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-xl-5 col-lg-5">
                <div class="single_about_text">
                    <h3>Cara <br> Memesan</h3>
                    <p class="about_text1">1. Pilih paket menu lalu klik Pesan Sekarang (login atau daftar dulu kalau belum punya akun).</p>
                    <p class="about_text2">2. Isi jumlah porsi, tanggal, jam, dan alamat pengiriman.</p>
                    <p class="about_text2">3. Transfer lalu upload bukti pembayaran. Setelah dicek admin, pesananmu langsung dimasak.</p>
                    <a href="<?php echo e(route('pelanggan.menu')); ?>" class="boxed_btn">Mulai Pesan</a>
                </div>
            </div>
            <div class="col-xl-6 offset-xl-1 col-lg-6 offset-lg-1">
                <div class="single_about_thumb thumb_n1">
                    <img src="<?php echo e(asset('flatter-master/img/about/1.png')); ?>" alt="">
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Cara Pesan -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pelanggan.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\www\layanan-catering\resources\views/pelanggan/pages/beranda.blade.php ENDPATH**/ ?>