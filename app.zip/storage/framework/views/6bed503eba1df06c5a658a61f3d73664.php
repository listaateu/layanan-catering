<?php $__env->startSection('content'); ?>
<div>
    <!-- Selamat Datang -->
    <div class="page-header">
        <div>
            <h1 class="page-title">Selamat Datang, <?php echo e(auth()->user()->nama); ?></h1>
            <p class="page-subtitle"><?php echo e(date('d-m-Y')); ?></p>
        </div>
    </div>
    <!-- Selamat Datang -->

    <!-- Card Info -->
    
    <div class="row mx-2 my-4">
        <div class="col-md-6 col-xxl-3 my-2">
            <div class="card">
                <div class="card-body d-flex justify-content-start">
                    <div class="icon bg-warning d-flex rounded p-3 me-3">
                        <i class="bi bi-hourglass-split text-light m-auto fs-2"></i>
                    </div>
                    <div class="card-text align-content-center">
                        <h5 class="mb-1">Antrean Dapur</h5>
                        <h6 class="m-0"><?php echo e($antrean); ?></h6>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-xxl-3 my-2">
            <div class="card">
                <div class="card-body d-flex justify-content-start">
                    <div class="icon bg-danger d-flex rounded p-3 me-3">
                        <i class="bi bi-fire text-light m-auto fs-2"></i>
                    </div>
                    <div class="card-text align-content-center">
                        <h5 class="mb-1">Sedang Dimasak</h5>
                        <h6 class="m-0"><?php echo e($dimasak); ?></h6>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-xxl-3 my-2">
            <div class="card">
                <div class="card-body d-flex justify-content-start">
                    <div class="icon bg-primary d-flex rounded p-3 me-3">
                        <i class="bi bi-box-seam-fill text-light m-auto fs-2"></i>
                    </div>
                    <div class="card-text align-content-center">
                        <h5 class="mb-1">Siap Kirim</h5>
                        <h6 class="m-0"><?php echo e($siapKirim); ?></h6>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-xxl-3 my-2">
            <div class="card">
                <div class="card-body d-flex justify-content-start">
                    <div class="icon bg-success d-flex rounded p-3 me-3">
                        <i class="bi bi-check-circle-fill text-light m-auto fs-2"></i>
                    </div>
                    <div class="card-text align-content-center">
                        <h5 class="mb-1">Terkirim</h5>
                        <h6 class="m-0"><?php echo e($terkirim); ?></h6>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Card Info -->

    <!-- Kerjaan Terdekat -->
    <div class="row mx-2 my-4">
        <div class="col-md-12">
            <div class="table-card-custom">
                <div class="table-header-control">
                    <h5 class="mb-0">Pesanan yang Harus Dikerjakan</h5>
                    <a href="<?php echo e(route('dapur.produksi.table')); ?>" class="btn-custom btn-custom-light">Lihat Semua</a>
                </div>
                <div class="table-responsive">
                    <table class="table-custom">
                        <thead>
                            <tr>
                                <th>Kode Order</th>
                                <th>Menu</th>
                                <th>Tanggal Acara</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            
                            <?php $__empty_1 = true; $__currentLoopData = $kerjaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="table-order-id"><?php echo e($item->order->kode_order); ?></td>
                                <td>
                                    <?php $__currentLoopData = $item->order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div><?php echo e($detail->package->nama_paket); ?> <span class="table-user-sub">(<?php echo e($detail->jumlah_porsi); ?> porsi)</span></div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                <td><?php echo e($item->order->tanggal_acara->format('d-m-Y')); ?> <div class="table-user-sub">Pukul <?php echo e(substr($item->order->jam_kirim, 0, 5)); ?></div></td>
                                <td><span class="badge-table <?php echo e($item->status_badge); ?>"><?php echo e($item->status_label); ?></span></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="4" class="text-center py-4">Tidak ada pesanan yang harus dikerjakan</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- Kerjaan Terdekat -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dapur.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\www\layanan-catering\resources\views/dapur/pages/dashboard.blade.php ENDPATH**/ ?>