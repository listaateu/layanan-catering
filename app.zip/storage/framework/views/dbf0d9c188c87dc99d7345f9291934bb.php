<?php $__env->startSection('content'); ?>
<!-- Judul Halaman -->
<div class="breadcam_area breadcam_bg_1 zigzag_bg_2">
    <div class="breadcam_inner">
        <div class="breadcam_text">
            <h3>Pesan Sekarang</h3>
            <p>Isi data pesananmu di bawah ini.</p>
        </div>
    </div>
</div>
<!-- Judul Halaman -->

<section class="contact-section">
    <div class="container">
        <div class="row">
            <!-- Ringkasan paket yang dipilih (hanya dibaca, tidak bisa diganti di sini) -->
            <div class="col-lg-5 mb-4">
                <img src="<?php echo e($paket->gambar_paket ? asset('storage/' . $paket->gambar_paket) : asset('flatter-master/img/order/order-1.png')); ?>"
                    alt="<?php echo e($paket->nama_paket); ?>" style="width: 100%; max-height: 300px; object-fit: cover;">
                <h4 class="mt-3"><?php echo e($paket->nama_paket); ?></h4>
                <p class="mb-1">Rp <?php echo e(number_format($paket->harga_porsi, 0, ',', '.')); ?> / porsi</p>
                <p class="mb-2">Minimal pesan <?php echo e($paket->min_porsi); ?> porsi</p>
                <ul class="isi-paket">
                    <?php $__currentLoopData = explode(',', $paket->deskripsi); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $isi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e(trim($isi)); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <a href="<?php echo e(route('pelanggan.menu')); ?>">Pilih paket lain</a>
            </div>

            <!-- Form pesan -->
            <div class="col-lg-7">
                <form action="<?php echo e(route('pelanggan.pesanan.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>

                    
                    <input type="hidden" name="id_paket" value="<?php echo e($paket->id_paket); ?>">

                    <div class="form-group">
                        <label for="jumlah_porsi">Jumlah Porsi <span class="text-danger">*</span></label>
                        <input type="number" class="form-control" name="jumlah_porsi" id="jumlah_porsi" value="<?php echo e(old('jumlah_porsi', $paket->min_porsi)); ?>" min="<?php echo e($paket->min_porsi); ?>" required>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="tanggal_acara">Tanggal Acara <span class="text-danger">*</span></label>
                                <input type="date" class="form-control" name="tanggal_acara" id="tanggal_acara" value="<?php echo e(old('tanggal_acara')); ?>" min="<?php echo e(date('Y-m-d')); ?>" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="jam_kirim">Jam Kirim <span class="text-danger">*</span></label>
                                <input type="time" class="form-control" name="jam_kirim" id="jam_kirim" value="<?php echo e(old('jam_kirim')); ?>" required>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="alamat_kirim">Alamat Kirim <span class="text-danger">*</span></label>
                        
                        <textarea class="form-control" name="alamat_kirim" id="alamat_kirim" rows="3" required><?php echo e(old('alamat_kirim', auth()->user()->alamat)); ?></textarea>
                    </div>

                    <p class="text-muted">Total bayar dihitung otomatis: harga per porsi x jumlah porsi.</p>

                    <button type="submit" class="boxed_btn">Buat Pesanan</button>
                    <a href="<?php echo e(route('pelanggan.menu')); ?>" class="boxed_btn_white">Batal</a>
                </form>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pelanggan.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\www\layanan-catering\resources\views/pelanggan/pages/pesanan/create.blade.php ENDPATH**/ ?>