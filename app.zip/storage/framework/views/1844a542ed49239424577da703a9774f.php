<script src="<?php echo e(asset('admin/spark/assets/libs/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/spark/assets/libs/apexcharts/apexcharts.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/spark/assets/libs/flatpickr/flatpickr.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/spark/assets/js/dashboard.js')); ?>"></script>

<!-- Sweetalert2 -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.26.25/dist/sweetalert2.all.min.js"></script>

<!-- Local Js -->
<script src="<?php echo e(asset('admin/spark/assets/js/script.js')); ?>"></script>
<?php /**PATH D:\www\layanan-catering\resources\views/admin/partials/script.blade.php ENDPATH**/ ?>