<?php $__env->startSection('content'); ?>
<?php
    $daftarStatus = [
        'antrean_dapur' => 'Antrean Dapur',
        'sedang_dimasak' => 'Sedang Dimasak',
        'siap_kirim' => 'Siap Kirim',
        'terkirim' => 'Terkirim',
    ];
?>
<div>
    <div class="page-header">
        <div>
            <h1 class="page-title">Produksi</h1>
            <p class="page-subtitle">Pantau antrean dan progres masakan di dapur.</p>
        </div>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>" class="text-decoration-none text-muted-green">Home</a></li>
                <li class="breadcrumb-item active text-main" aria-current="page">Produksi</li>
            </ol>
        </nav>
    </div>

    <div class="table-card-custom">
        <div class="table-header-control">
            <h5 class="mb-0">Data Produksi</h5>
            <div class="table-filter-group">
                <div class="dropdown">
                    <button class="btn-table-action dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="bi bi-funnel"></i> <?php echo e($daftarStatus[$status] ?? 'Semua Status'); ?>

                    </button>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="<?php echo e(route('admin.produksi.table')); ?>">Semua Status</a></li>
                        <?php $__currentLoopData = $daftarStatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a class="dropdown-item" href="<?php echo e(route('admin.produksi.table', ['status' => $key])); ?>"><?php echo e($label); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>

        <div class="table-responsive">
            <table class="table-custom">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Kode Order</th>
                        <th>Menu</th>
                        <th>Tanggal Acara</th>
                        <th>Status Produksi</th>
                        <th>Penanggung Jawab</th>
                        <th class="text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    
                    <?php $__empty_1 = true; $__currentLoopData = $produksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td class="table-order-id"><?php echo e($item->order->kode_order); ?></td>
                        <td>
                            <?php $__currentLoopData = $item->order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div><?php echo e($detail->package->nama_paket); ?> <span class="table-user-sub">(<?php echo e($detail->jumlah_porsi); ?> porsi)</span></div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        <td>
                            <?php echo e($item->order->tanggal_acara->locale('id')->translatedFormat('d F Y')); ?>

                            <div class="table-user-sub">Pukul <?php echo e(substr($item->order->jam_kirim, 0, 5)); ?></div>
                        </td>
                        <td><span class="badge-table <?php echo e($item->status_badge); ?>"><?php echo e($item->status_label); ?></span></td>
                        <td><?php echo e($item->handler->nama ?? '-'); ?></td>
                        <td>
                            <div class="d-flex justify-content-center gap-1">
                                <a href="<?php echo e(route('admin.pesanan.show', $item->id_order)); ?>" class="table-btn-action" title="Lihat pesanan">
                                    <i class="bi bi-eye"></i>
                                </a>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="text-center py-4">Belum ada pesanan di antrean dapur</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="table-footer-control">
            <span class="table-pagination-info">Total <?php echo e($produksi->count()); ?> jadwal produksi</span>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\www\layanan-catering\resources\views/admin/pages/produksi/produksi.blade.php ENDPATH**/ ?>