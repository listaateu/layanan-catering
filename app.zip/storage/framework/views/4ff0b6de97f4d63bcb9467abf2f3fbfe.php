<div class="sidebar-wrapper" id="sidebar">
    <!-- Sidebar Logo -->
    <a href="<?php echo e(route('dapur.dashboard')); ?>" class="sidebar-brand">
        <i class="bi bi-egg-fried"></i>
        <span>Dapur Catering</span>
    </a>
    <!-- Sidebar Logo -->

    <!-- Sidebar Navigation -->
    <div class="flex-grow-1 overflow-y-auto">
        <div class="sidebar-menu-section">
            <div class="sidebar-menu-title">Menu</div>
            <ul class="sidebar-menu-list">
                
                <li class="sidebar-menu-item">
                    <a class="sidebar-menu-link <?php echo e(request()->routeIs('dapur.dashboard') ? 'active' : ''); ?>" href="<?php echo e(route('dapur.dashboard')); ?>">
                        <i class="bi bi-grid-fill"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                <li class="sidebar-menu-item">
                    <a class="sidebar-menu-link <?php echo e(request()->routeIs('dapur.produksi*') ? 'active' : ''); ?>" href="<?php echo e(route('dapur.produksi.table')); ?>">
                        <i class="bi bi-fire"></i>
                        <span>Produksi</span>
                    </a>
                </li>
                <li class="sidebar-menu-item">
                    <a class="sidebar-menu-link <?php echo e(request()->routeIs('dapur.riwayat*') ? 'active' : ''); ?>" href="<?php echo e(route('dapur.riwayat.table')); ?>">
                        <i class="bi bi-clock-history"></i>
                        <span>Riwayat</span>
                    </a>
                </li>
            </ul>
        </div>
    </div>
    <!-- Sidebar Navigation -->

    <!-- Sidebar Profile -->
    <div class="sidebar-profile">
        <img src="<?php echo e(asset('admin/spark/assets/images/avatar.png')); ?>" alt="Kepala Dapur" class="sidebar-profile-img">
        <div class="sidebar-profile-info">
            <div class="sidebar-profile-name"><?php echo e(auth()->user()->nama); ?></div>
            <div class="sidebar-profile-email"><?php echo e(auth()->user()->email); ?></div>
        </div>
    </div>
    <!-- Sidebar Profile -->
</div>
<?php /**PATH D:\www\layanan-catering\resources\views/dapur/components/sidebar.blade.php ENDPATH**/ ?>