<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ProductionSchedule extends Model
{
    use HasFactory;

    protected $table = 'production_schedules';
    protected $primaryKey = 'id_produksi';

    protected $fillable = [
        'id_order',
        'handled_by',
        'status_produksi',
    ];

    // accessor = function get...Attribute, dipanggil kayak kolom: $produksi->status_label
    // fungsinya ngubah "sedang_dimasak" jadi "Sedang Dimasak"
    public function getStatusLabelAttribute()
    {
        return ucwords(str_replace('_', ' ', $this->status_produksi));
    }

    // dipanggil pakai $produksi->status_badge
    // fungsinya nentuin warna label: kuning (pending) kalau belum jadi, hijau (success) kalau sudah
    public function getStatusBadgeAttribute()
    {
        if ($this->status_produksi == 'antrean_dapur' || $this->status_produksi == 'sedang_dimasak') {
            return 'pending';
        }

        return 'success';
    }

    public function order()
    {
        return $this->belongsTo(Order::class, 'id_order', 'id_order');
    }

    public function handler()
    {
        return $this->belongsTo(User::class, 'handled_by', 'id_user');
    }
}
