<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    use HasFactory;

    protected $table = 'orders';
    protected $primaryKey = 'id_order';

    protected $fillable = [
        'id_customer',
        'kode_order',
        'tanggal_acara',
        'jam_kirim',
        'alamat_kirim',
        'total_bayar',
        'status_pesanan',
    ];

    protected $casts = [
        'tanggal_acara' => 'date',
    ];

    // accessor = function yang namanya get...Attribute, bisa dipanggil kayak kolom biasa
    // di halaman tinggal tulis $order->status_label
    // fungsinya ngubah "menunggu_pembayaran" jadi "Menunggu Pembayaran" biar rapi
    public function getStatusLabelAttribute()
    {
        return ucwords(str_replace('_', ' ', $this->status_pesanan));
    }

    // yang ini dipanggil pakai $order->status_badge
    // fungsinya nentuin warna label status: kuning (pending), merah (failed), hijau (success)
    public function getStatusBadgeAttribute()
    {
        if ($this->status_pesanan == 'menunggu_pembayaran') {
            return 'pending';
        }

        if ($this->status_pesanan == 'dibatalkan') {
            return 'failed';
        }

        return 'success';
    }

    public function customer()
    {
        return $this->belongsTo(User::class, 'id_customer', 'id_user');
    }

    public function items()
    {
        return $this->hasMany(OrderItem::class, 'id_order', 'id_order');
    }

    public function payment()
    {
        return $this->hasOne(Payment::class, 'id_order', 'id_order');
    }

    public function productionSchedule()
    {
        return $this->hasOne(ProductionSchedule::class, 'id_order', 'id_order');
    }
}
