<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

class CekAdminKasir
{
    public function handle(Request $request, Closure $next): Response
    {
        if (!Auth::check()) {
            return redirect()->route('login')->with('error', 'Silahkan login terlebih dahulu');
        }

        if (Auth::user()->role !== 'admin_kasir') {
            abort(403, 'Anda tidak memiliki akses ke halaman ini!');
        }

        return $next($request);
    }
}
