<?php

namespace App\Http\Controllers\pelanggan;

use App\Http\Controllers\Controller;
use App\Models\CateringPackage;
use App\Models\Order;
use App\Models\OrderItem;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class PesananController extends Controller
{
    //index -> tampilin daftar pesanan milik pelanggan yang lagi login
    public function index()
    {
        $pesanan = Order::where('id_customer', Auth::user()->id_user)->latest()->get();

        return view('pelanggan.pages.pesanan.pesanan', compact('pesanan'));
    }

    //create -> tampilin form pesan untuk paket yang dipilih
    public function create($id)
    {
        $paket = CateringPackage::find($id);

        // paket ga ada atau nonaktif ga boleh dipesan
        if (!$paket || $paket->status_aktif != 'aktif') {
            return redirect()->route('pelanggan.menu')->with('error', 'Paket tidak tersedia');
        }

        return view('pelanggan.pages.pesanan.create', compact('paket'));
    }

    //store -> simpan pesanan baru
    public function store(Request $request)
    {
        $request->validate([
            'id_paket'      => 'required|exists:catering_packages,id_paket',
            'jumlah_porsi'  => 'required|integer|min:1',
            'tanggal_acara' => 'required|date|after_or_equal:today',
            'jam_kirim'     => 'required',
            'alamat_kirim'  => 'required|string',
        ]);

        $paket = CateringPackage::find($request->id_paket);

        if ($paket->status_aktif != 'aktif') {
            return redirect()->back()->withInput()->with('error', 'Paket ini sedang tidak tersedia');
        }

        if ($request->jumlah_porsi < $paket->min_porsi) {
            return redirect()->back()->withInput()->with('error', 'Minimal pesan paket ini ' . $paket->min_porsi . ' porsi');
        }

        // total = harga per porsi x jumlah porsi
        $total = $paket->harga_porsi * $request->jumlah_porsi;

        // kode pesanan contoh: ORD-20261126-005
        $kode = 'ORD-' . date('Ymd') . '-' . str_pad(Order::count() + 1, 3, '0', STR_PAD_LEFT);

        $pesanan = Order::create([
            'id_customer'    => Auth::user()->id_user,
            'kode_order'     => $kode,
            'tanggal_acara'  => $request->tanggal_acara,
            'jam_kirim'      => $request->jam_kirim,
            'alamat_kirim'   => $request->alamat_kirim,
            'total_bayar'    => $total,
            'status_pesanan' => 'menunggu_pembayaran',
        ]);

        // harga_satuan ikut disimpan, biar kalau harga paket berubah pesanan lama tetap aman
        OrderItem::create([
            'id_order'     => $pesanan->id_order,
            'id_paket'     => $paket->id_paket,
            'jumlah_porsi' => $request->jumlah_porsi,
            'harga_satuan' => $paket->harga_porsi,
            'subtotal'     => $total,
        ]);

        return redirect()->route('pelanggan.pesanan.show', $pesanan->id_order)
            ->with('success', 'Pesanan berhasil dibuat. Silakan bayar tunai ke kasir');
    }

    //show -> tampilin detail satu pesanan
    public function show($id)
    {
        // harus pesanan milik sendiri
        $pesanan = Order::where('id_order', $id)->where('id_customer', Auth::user()->id_user)->first();

        if (!$pesanan) {
            abort(404);
        }

        return view('pelanggan.pages.pesanan.show', compact('pesanan'));
    }

    //batal -> batalin pesanan (uang dikembalikan langsung sama kasir)
    public function batal(Order $pesanan)
    {
        // pesanan orang lain ga boleh dibatalin
        if ($pesanan->id_customer != Auth::user()->id_user) {
            abort(403);
        }

        // yang sudah dimasak ga bisa dibatalin
        if (!in_array($pesanan->status_pesanan, ['menunggu_pembayaran', 'terkonfirmasi'])) {
            return redirect()->route('pelanggan.pesanan.show', $pesanan->id_order)
                ->with('error', 'Pesanan dengan status ini tidak bisa dibatalkan');
        }

        // kalau sudah masuk antrean dapur, jadwalnya dihapus
        if ($pesanan->productionSchedule) {
            $pesanan->productionSchedule->delete();
        }

        $pesanan->update([
            'status_pesanan' => 'dibatalkan',
        ]);

        return redirect()->route('pelanggan.pesanan.table')->with('success', 'Pesanan ' . $pesanan->kode_order . ' berhasil dibatalkan');
    }
}
