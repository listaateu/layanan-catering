<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use App\Models\CateringPackage;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class PaketController extends Controller
{
    // index -> menampilkan halaman utama (semua paket)
    public function index()
    {
        // latest() = data yang paling baru ada di atas
        // get() = ambil semua datanya
        $paket = CateringPackage::latest()->get();
        return view('admin.pages.paket.paket', compact('paket'));
    }

    // create -> menampilkan halaman tambah (hanya menampilkan form kosong)
    public function create()
    {
        return view('admin.pages.paket.create');
    }

    // store -> menjalankan fungsi tambah data (dipanggil saat tombol Simpan ditekan)
    public function store(Request $request)
    {
        // validasi inputan dari form
        // kalau ada yang tidak sesuai, otomatis kembali ke form dan menampilkan pesan error
        // required = wajib diisi, nullable = boleh kosong, max = batas maksimal
        // image|mimes = harus berupa gambar dengan format jpg/jpeg/png/webp, max:2048 = maksimal 2 MB
        // in:aktif,nonaktif = isinya hanya boleh salah satu dari dua pilihan itu
        $request->validate([
            'nama_paket'   => 'required|string|max:255',
            'deskripsi'    => 'nullable|string',
            'harga_porsi'  => 'required|numeric|min:1|max:9999999999',
            'min_porsi'    => 'required|integer|min:1',
            'gambar_paket' => 'nullable|image|mimes:jpg,jpeg,png,webp|max:2048',
            'status_aktif' => 'required|in:aktif,nonaktif',
        ], [
            // pesan error buatan sendiri (supaya berbahasa Indonesia)
            'harga_porsi.min' => 'Harga per porsi harus lebih dari 0',
            'harga_porsi.max' => 'Harga per porsi terlalu besar',
            'min_porsi.min'   => 'Minimal porsi harus lebih dari 0',
        ]);

        // gambar boleh kosong, jadi awalnya diisi null dulu
        $gambar = null;

        // hasFile() = cek apakah ada file yang diupload
        if ($request->hasFile('gambar_paket')) {
            // Str::slug() = ubah nama paket jadi format url, contoh: "Paket Nasi Box" -> "paket-nasi-box"
            // time() dipakai supaya nama file tidak bentrok kalau ada 2 paket dengan nama yang sama
            // getClientOriginalExtension() = ambil jenis file aslinya (jpg / png / webp)
            $slug = Str::slug($request->nama_paket, '-');
            $filename = $slug . '-' . time() . '.' . $request->file('gambar_paket')->getClientOriginalExtension();

            // storeAs() = simpan file ke storage/app/public/paket dengan nama yang kita tentukan sendiri
            // yang disimpan di database hanya path-nya, contoh: paket/paket-nasi-box-1732420000.jpg
            $gambar = $request->file('gambar_paket')->storeAs('paket', $filename, 'public');
        }

        // create() = simpan data baru ke tabel catering_packages
        CateringPackage::create([
            'nama_paket'   => $request->nama_paket,
            'deskripsi'    => $request->deskripsi,
            'harga_porsi'  => $request->harga_porsi,
            'min_porsi'    => $request->min_porsi,
            'gambar_paket' => $gambar,
            'status_aktif' => $request->status_aktif,
        ]);

        // redirect = pindah ke halaman daftar paket, with() = membawa pesan sukses
        return redirect()->route('admin.paket.table')->with('success', 'Paket menu baru berhasil ditambahkan');
    }

    // edit -> menampilkan halaman update (form yang sudah terisi data lama)
    public function edit($id)
    {
        // findOrFail() = cari data berdasarkan id, kalau tidak ketemu tampil halaman 404
        $paket = CateringPackage::findOrFail($id);
        return view('admin.pages.paket.update', compact('paket'));
    }

    // update -> menjalankan fungsi edit data (dipanggil saat tombol Simpan Perubahan ditekan)
    // CateringPackage $paket = Laravel otomatis mencari paket sesuai id di alamat URL
    public function update(Request $request, CateringPackage $paket)
    {
        $request->validate([
            'nama_paket'   => 'required|string|max:255',
            'deskripsi'    => 'nullable|string',
            'harga_porsi'  => 'required|numeric|min:1|max:9999999999',
            'min_porsi'    => 'required|integer|min:1',
            'gambar_paket' => 'nullable|image|mimes:jpg,jpeg,png,webp|max:2048',
            'status_aktif' => 'required|in:aktif,nonaktif',
        ], [
            'harga_porsi.min' => 'Harga per porsi harus lebih dari 0',
            'harga_porsi.max' => 'Harga per porsi terlalu besar',
            'min_porsi.min'   => 'Minimal porsi harus lebih dari 0',
        ]);

        // pakai gambar yang lama dulu
        $gambar = $paket->gambar_paket;

        // kalau upload gambar baru, gambar lama dihapus dari storage lalu diganti dengan yang baru
        if ($request->hasFile('gambar_paket')) {
            if ($paket->gambar_paket) {
                Storage::disk('public')->delete($paket->gambar_paket);
            }

            // nama file dibuat dari nama paket yang baru (sama seperti di store)
            $slug = Str::slug($request->nama_paket, '-');
            $filename = $slug . '-' . time() . '.' . $request->file('gambar_paket')->getClientOriginalExtension();
            $gambar = $request->file('gambar_paket')->storeAs('paket', $filename, 'public');
        }

        // update() = ubah data yang sudah ada di database
        $paket->update([
            'nama_paket'   => $request->nama_paket,
            'deskripsi'    => $request->deskripsi,
            'harga_porsi'  => $request->harga_porsi,
            'min_porsi'    => $request->min_porsi,
            'gambar_paket' => $gambar,
            'status_aktif' => $request->status_aktif,
        ]);

        return redirect()->route('admin.paket.table')->with('success', 'Paket menu berhasil diubah');
    }

    // destroy -> menghapus data
    public function destroy(CateringPackage $paket)
    {
        // paket yang sudah pernah dipesan tidak boleh dihapus (kalau dipaksa akan error di database)
        // orderItems = relasi di model, berisi semua item pesanan yang memakai paket ini
        if ($paket->orderItems->count() > 0) {
            return redirect()->route('admin.paket.table')->with('error', 'Paket tidak bisa dihapus karena sudah dipakai di pesanan');
        }

        // hapus file gambarnya juga supaya storage tidak penuh file yang tidak terpakai
        if ($paket->gambar_paket) {
            Storage::disk('public')->delete($paket->gambar_paket);
        }

        // delete() = hapus data dari database
        $paket->delete();

        return redirect()->route('admin.paket.table')->with('success', 'Paket menu berhasil dihapus');
    }
}
