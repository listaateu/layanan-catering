<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\Payment;
use App\Models\ProductionSchedule;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class PembayaranController extends Controller
{
    //index -> tampilin 2 tabel: pesanan yang belum bayar dan pembayaran yang sudah diterima
    public function index()
    {
        $belumBayar = Order::where('status_pesanan', 'menunggu_pembayaran')->latest()->get();
        $pembayaran = Payment::latest()->get();

        return view('admin.pages.pembayaran.pembayaran', compact('belumBayar', 'pembayaran'));
    }

    //create -> tampilin form terima pembayaran tunai
    public function create($id)
    {
        $pesanan = Order::find($id);

        // kalau sudah dibayar atau dibatalkan, ga perlu form lagi
        if ($pesanan->status_pesanan != 'menunggu_pembayaran') {
            return redirect()->route('admin.pembayaran.table')->with('error', 'Pesanan ini tidak sedang menunggu pembayaran');
        }

        return view('admin.pages.pembayaran.create', compact('pesanan'));
    }

    //store -> simpan pembayaran tunai, pesanan langsung masuk antrean dapur
    public function store(Request $request, Order $pesanan)
    {
        $request->validate([
            'jumlah_bayar'  => 'required|numeric|min:1',
            'tanggal_bayar' => 'required|date|before_or_equal:today',
        ]);

        if ($pesanan->status_pesanan != 'menunggu_pembayaran') {
            return redirect()->route('admin.pembayaran.table')->with('error', 'Pesanan ini tidak sedang menunggu pembayaran');
        }

        // uang yang diterima harus pas sama total pesanan
        if ($request->jumlah_bayar != $pesanan->total_bayar) {
            return redirect()->back()->withInput()->with('error', 'Jumlah bayar harus sama dengan total pesanan');
        }

        Payment::create([
            'id_order'      => $pesanan->id_order,
            'verified_by'   => Auth::user()->id_user,
            'jumlah_bayar'  => $request->jumlah_bayar,
            'tanggal_bayar' => $request->tanggal_bayar,
        ]);

        $pesanan->update([
            'status_pesanan' => 'terkonfirmasi',
        ]);

        // dibuatin jadwal produksi biar muncul di antrean dapur
        ProductionSchedule::create([
            'id_order'        => $pesanan->id_order,
            'status_produksi' => 'antrean_dapur',
        ]);

        return redirect()->route('admin.pembayaran.table')->with('success', 'Pembayaran ' . $pesanan->kode_order . ' diterima, pesanan masuk antrean dapur');
    }

    //show -> tampilin detail pembayaran
    public function show($id)
    {
        $pembayaran = Payment::find($id);

        return view('admin.pages.pembayaran.show', compact('pembayaran'));
    }
}
