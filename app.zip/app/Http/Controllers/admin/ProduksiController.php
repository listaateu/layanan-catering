<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use App\Models\ProductionSchedule;
use Illuminate\Http\Request;

class ProduksiController extends Controller
{
    //index -> tampilin antrean dapur, admin cuma bisa lihat (yang ubah status kepala dapur)
    public function index(Request $request)
    {
        $status = $request->status;

        if ($status) {
            $produksi = ProductionSchedule::where('status_produksi', $status)->get();
        } else {
            $produksi = ProductionSchedule::get();
        }

        return view('admin.pages.produksi.produksi', compact('produksi', 'status'));
    }
}
