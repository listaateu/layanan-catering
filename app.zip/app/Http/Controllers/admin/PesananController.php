<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use App\Models\Order;
use Illuminate\Http\Request;

class PesananController extends Controller
{
    //index -> tampilin daftar pesanan, bisa difilter status
    public function index(Request $request)
    {
        $status = $request->status;

        if ($status) {
            $pesanan = Order::where('status_pesanan', $status)->latest()->get();
        } else {
            $pesanan = Order::latest()->get();
        }

        return view('admin.pages.pesanan.pesanan', compact('pesanan', 'status'));
    }

    //show -> tampilin detail satu pesanan
    public function show($id)
    {
        $pesanan = Order::find($id);

        return view('admin.pages.pesanan.show', compact('pesanan'));
    }

    //batal -> batalin pesanan
    public function batal(Order $pesanan)
    {
        // pesanan yang sudah dimasak atau selesai ga bisa dibatalin
        if (!in_array($pesanan->status_pesanan, ['menunggu_pembayaran', 'terkonfirmasi'])) {
            return redirect()->route('admin.pesanan.show', $pesanan->id_order)
                ->with('error', 'Pesanan dengan status ini tidak bisa dibatalkan');
        }

        // kalau sudah masuk antrean dapur, jadwalnya dihapus
        if ($pesanan->productionSchedule) {
            $pesanan->productionSchedule->delete();
        }

        $pesanan->update([
            'status_pesanan' => 'dibatalkan',
        ]);

        return redirect()->route('admin.pesanan.table')->with('success', 'Pesanan ' . $pesanan->kode_order . ' berhasil dibatalkan');
    }
}
