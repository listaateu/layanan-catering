<?php

use App\Http\Controllers\AuthController as LoginController;
use App\Http\Controllers\admin\DashboardController as AdminDashboardController;
use App\Http\Controllers\admin\PaketController as AdminPaketController;
use App\Http\Controllers\admin\PesananController as AdminPesananController;
use App\Http\Controllers\admin\PembayaranController as AdminPembayaranController;
use App\Http\Controllers\admin\ProduksiController as AdminProduksiController;
use App\Http\Middleware\CekAdminKasir;
use Illuminate\Support\Facades\Route;

// Head Http
Route::get('/', function () {
    return redirect()->route('login');
});

// Login Page
Route::prefix('login')->group(function () {
    Route::get('/', [LoginController::class, 'index'])->name('login');
    Route::post('/', [LoginController::class, 'authenticate'])->name('authenticate');
});

Route::post('/logout', [LoginController::class, 'logout'])->name('logout');

// Admin Kasir
Route::prefix('admin-kasir')->as('admin.')->middleware([CekAdminKasir::class])->group(function () {
    Route::get('/', [AdminDashboardController::class, 'index'])->name('dashboard');
    Route::prefix('paket')->as('paket.')->group(function () {
        Route::get('/', [AdminPaketController::class, 'index'])->name('table');
        Route::get('/create', [AdminPaketController::class, 'create'])->name('create');
        Route::post('/create', [AdminPaketController::class, 'store'])->name('store');
        Route::get('/update/{id}', [AdminPaketController::class, 'edit'])->name('edit');
        Route::put('/update/{paket}', [AdminPaketController::class, 'update'])->name('update');
        Route::delete('/delete/{paket}', [AdminPaketController::class, 'destroy'])->name('destroy');
    });
    Route::prefix('pesanan')->as('pesanan.')->group(function () {
        Route::get('/', [AdminPesananController::class, 'index'])->name('table');
        Route::get('/show/{id}', [AdminPesananController::class, 'show'])->name('show');
        Route::put('/batal/{pesanan}', [AdminPesananController::class, 'batal'])->name('batal');
    });
    Route::prefix('pembayaran')->as('pembayaran.')->group(function () {
        Route::get('/', [AdminPembayaranController::class, 'index'])->name('table');
        Route::get('/update/{id}', [AdminPembayaranController::class, 'edit'])->name('validasi');
        Route::put('/update/{pembayaran}', [AdminPembayaranController::class, 'update'])->name('update');
        Route::get('/show/{id}', [AdminPembayaranController::class, 'show'])->name('show');
    });
    Route::prefix('produksi')->as('produksi.')->group(function () {
        Route::get('/', [AdminProduksiController::class, 'index'])->name('table');
    });
});
